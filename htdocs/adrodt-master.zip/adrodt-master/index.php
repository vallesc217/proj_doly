<?php
/******************************************************************
 * adrodt is a Dolibarr module
 * It add field for delivred address when generate 
 * document from odt
 *
 * adrodt is distributed under GNU/GPLv3 license
 * (see COPYING file)
 *
 * Author : Befox SARL http://www.befox.fr/
 *
 ******************************************************************/

