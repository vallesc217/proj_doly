<?php
$locale_arr = array (
    "language" => "Portugu�s Brasileiro",
    "template" => array (
        "T_CHOOSE_LANGUAGE" => "Escolha o idioma",
        "T_GO" => "Ir",
        "T_LOGGED_IN_AS" => "Logado como",
        "T_LOGIN" => "Entrar",
        "T_LOGOFF" => "Sair",
        "T_ADMIN_HOME" => "Pagina de Administracao",
        "T_CONFIG_PROJECT" => "Configurar Projeto",
        "T_CREATE_REPORT" => "Criar Relatorio",
        "T_ENTER_PROJECT_PASSWORD" => "Informe a senha do projeto.",
        "T_ENTER_PROJECT_PASSWORD_DEMO" => "Informe a senha do projeto. <br>A senha para estes tutoriais e <b>reportico</b>",
        "T_UNABLE_TO_CONTINUE" => "N�o foi possivel continuar",
        "T_PASSWORD_ERROR" => "Senha incorreta. Tente novamente.",
        ),
        );
?>
