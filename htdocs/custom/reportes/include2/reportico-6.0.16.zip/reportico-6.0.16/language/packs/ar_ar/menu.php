<?php
$locale_arr = array (
    "language" => "English",
    "template" => array (
        "T_CHOOSE_LANGUAGE" => "اختيار اللغة",
        "T_GO" => "الذهاب",
        "T_LOGGED_IN_AS" => "مسجله في",
        "T_LOGIN" => "تسجيل الدخول",
        "T_LOGOFF" => "تسجيل الخروج",
        "T_ADMIN_HOME" => "مشرف الصفحة الرئيسية",
        "T_CONFIG_PROJECT" => "تكوين مشروع",
        "T_CREATE_REPORT" => "إنشاء تقرير",
        "T_ENTER_PROJECT_PASSWORD" => "أدخل كلمة المرور المشروع.",
        "T_ENTER_PROJECT_PASSWORD_DEMO" => "أدخل كلمة المرور المشروع. كلمة السر لهذه الدروس هو <b>reportico</b>",
        "T_UNABLE_TO_CONTINUE" => "غير قادر على الاستمرار",
        "T_PASSWORD_ERROR" => "غير صحيح كلمة السر. حاول مرة أخرى.",
        ),
        );
?>
