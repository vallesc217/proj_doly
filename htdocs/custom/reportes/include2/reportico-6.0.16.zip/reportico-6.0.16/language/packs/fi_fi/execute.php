<?php
$locale_arr = array (
"language" => "Finnish",
"template" => array (
        // Maintenance Buttons
		"T_GO_PRINT" => "Tulosta",
		"T_GO_BACK" => "Paluu",
		"T_GO_REFRESH" => "Päivitä",
		"T_NO_DATA_FOUND" => "Valituilla arvoilla ei löydy tuloksia",
		"T_UNABLE_TO_CONTINUE" => "Toimintoa ei voi jatkaa",
		"T_INFORMATION" => "Informaatio",
        "T_REQUIRED_CRITERIA" => "Sinun täytyy antaa valinnalle joku arvo ",
        "T_NOTICE" => "Huomio",
        )
);
?>
