<?php

$rows = [
[ "id" => "8", "first_name" => "Laura", "last_name" => "Callahan", "date_of_birth" => "1958-01-09", "country" => "USA" ],
[ "id" => "1", "first_name" => "Nancy", "last_name" => "Davolio", "date_of_birth" => "1968-12-08", "country" => "USA" ],
[ "id" => "2", "first_name" => "Andrew", "last_name" => "Fuller", "date_of_birth" => "1952-02-19", "country" => "USA" ],
[ "id" => "3", "first_name" => "Janet", "last_name" => "Leverling", "date_of_birth" => "1963-08-30", "country" => "USA" ],
[ "id" => "4", "first_name" => "Margaret", "last_name" => "Peacock", "date_of_birth" => "1958-09-19", "country" => "USA" ],
[ "id" => "5", "first_name" => "Steven", "last_name" => "Buchanan", "date_of_birth" => "1955-03-04", "country" => "UK" ],
[ "id" => "9", "first_name" => "Anne", "last_name" => "Dodsworth", "date_of_birth" => "1969-07-02", "country" => "UK" ],
[ "id" => "7", "first_name" => "Robert", "last_name" => "King", "date_of_birth" => "1960-05-29", "country" => "UK" ],
[ "id" => "6", "first_name" => "Michael", "last_name" => "Suyama", "date_of_birth" => "1963-07-02", "country" => "UK" ],
];


?>
